using System;
using System.Collections.Generic;
using System.Text;

namespace LibrarySystem
{
    public class Library
    {
        private List<Book> books = new List<Book>();
        private List<Reader> readers = new List<Reader>();
        private List<BookIssue> issues = new List<BookIssue>();
        private int nextBookId = 1;
        private int nextReaderId = 1;
        private int nextIssueId = 1;

        public void AddBook(string isbn, string title, string author, int year, int copies)
        {
            var book = new Book(isbn, title, author, year, copies);
            books.Add(book);
        }

        public void AddReader(string fullName, string phone)
        {
            var reader = new Reader(nextReaderId++, fullName, phone);
            readers.Add(reader);
        }

        public void IssueBook(string isbn, int readerId, DateTime dueDate)
        {
            var book = books.Find(b => b.ISBN == isbn);
            if (book == null)
                throw new ArgumentException("Книга не найдена");
            
            var reader = readers.Find(r => r.ID == readerId);
            if (reader == null)
                throw new ArgumentException("Читатель не найден");
            
            var issue = new BookIssue(nextIssueId++, book, reader, DateTime.Now, dueDate);
            issues.Add(issue);
        }

        public void ReturnBook(int issueId)
        {
            var issue = issues.Find(i => i.ID == issueId);
            if (issue == null)
                throw new ArgumentException("Выдача не найдена");
            
            issue.ReturnBook();
        }

        public string GetAllBooksInfo()
        {
            var sb = new StringBuilder();
            foreach (var book in books)
            {
                sb.AppendLine(book.GetInfo());
                sb.AppendLine("------------------");
            }
            return sb.ToString();
        }

        public string GetAllReadersInfo()
        {
            var sb = new StringBuilder();
            foreach (var reader in readers)
            {
                sb.AppendLine(reader.GetInfo());
                sb.AppendLine("------------------");
            }
            return sb.ToString();
        }

        public string GetAllIssuesInfo()
        {
            var sb = new StringBuilder();
            foreach (var issue in issues)
            {
                sb.AppendLine(issue.GetInfo());
                sb.AppendLine("------------------");
            }
            return sb.ToString();
        }
    }
}
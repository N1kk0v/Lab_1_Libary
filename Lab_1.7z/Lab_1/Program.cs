using System;

namespace LibrarySystem
{
    class Program
    {
        static void Main(string[] args)
        {
            var library = new Library();
            
            // Добавляем книги
            library.AddBook("978-5-699-12014-7", "Война и мир", "Лев Толстой", 1869, 5);
            library.AddBook("978-5-17-090823-3", "Преступление и наказание", "Фёдор Достоевский", 1866, 3);
            
            // Добавляем читателей
            library.AddReader("Иванов Иван Иванович", "+7 (123) 456-78-90");
            library.AddReader("Петров Петр Петрович", "+7 (987) 654-32-10");
            
            // Выдаем книги
            library.IssueBook("978-5-699-12014-7", 1, DateTime.Now.AddDays(14));
            library.IssueBook("978-5-17-090823-3", 2, DateTime.Now.AddDays(7));
            
            // Выводим информацию
            Console.WriteLine("=== Книги ===");
            Console.WriteLine(library.GetAllBooksInfo());
            
            Console.WriteLine("\n=== Читатели ===");
            Console.WriteLine(library.GetAllReadersInfo());
            
            Console.WriteLine("\n=== Выдачи ===");
            Console.WriteLine(library.GetAllIssuesInfo());
            
            // Возвращаем книгу
            library.ReturnBook(1);
            
            Console.WriteLine("\n=== После возврата ===");
            Console.WriteLine(library.GetAllBooksInfo());
            Console.WriteLine(library.GetAllIssuesInfo());
        }
    }
}
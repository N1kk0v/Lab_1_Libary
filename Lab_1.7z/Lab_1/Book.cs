using System;

namespace LibrarySystem
{
    public class Book
    {
        public string ISBN { get; }
        public string Title { get; }
        public string Author { get; }
        public int Year { get; }
        public int AvailableCopies { get; private set; }
        public int TotalCopies { get; }

        public Book(string isbn, string title, string author, int year, int copies)
        {
            if (string.IsNullOrWhiteSpace(isbn))
                throw new ArgumentException("ISBN не может быть пустым");
            if (string.IsNullOrWhiteSpace(title))
                throw new ArgumentException("Название не может быть пустым");
            if (copies <= 0)
                throw new ArgumentException("Количество копий должно быть положительным");

            ISBN = isbn;
            Title = title;
            Author = author;
            Year = year;
            AvailableCopies = copies;
            TotalCopies = copies;
        }

        public void Take()
        {
            if (AvailableCopies <= 0)
                throw new InvalidOperationException("Нет доступных копий этой книги");
            AvailableCopies--;
        }

        public void Return()
        {
            if (AvailableCopies >= TotalCopies)
                throw new InvalidOperationException("Все копии этой книги уже возвращены");
            AvailableCopies++;
        }

        public string GetInfo()
        {
            return $"Книга: {Title}\nАвтор: {Author}\nГод: {Year}\nISBN: {ISBN}\n" +
                   $"Доступно: {AvailableCopies} из {TotalCopies}";
        }
    }
}
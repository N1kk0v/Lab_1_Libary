using System;

namespace LibrarySystem
{
    public class Reader
    {
        public int ID { get; }
        public string FullName { get; }
        public string Phone { get; }
        public DateTime RegistrationDate { get; }

        public Reader(int id, string fullName, string phone)
        {
            if (string.IsNullOrWhiteSpace(fullName))
                throw new ArgumentException("ФИО не может быть пустым");

            ID = id;
            FullName = fullName;
            Phone = phone;
            RegistrationDate = DateTime.Now;
        }

        public string GetInfo()
        {
            return $"Читатель: {FullName}\nID: {ID}\nТелефон: {Phone}\n" +
                   $"Дата регистрации: {RegistrationDate.ToShortDateString()}";
        }
    }
}
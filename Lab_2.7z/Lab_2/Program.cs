﻿using System;
using System.Threading.Tasks;

namespace LibrarySystem
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var library = new Library();
            
            try
            {
                Console.WriteLine("=== Библиотечная система ===");
                
                // Загрузка данных
                await LoadLibraryDataAsync(library);
                
                // Проверка и инициализация тестовых данных
                InitializeSampleData(library);
                
                // Основное меню
                await RunMainMenu(library);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Критическая ошибка: {ex.Message}");
            }
            finally
            {
                // Сохранение данных перед выходом
                await SaveLibraryDataAsync(library);
                Console.WriteLine("\nДанные сохранены. Программа завершена.");
            }
        }

        private static async Task LoadLibraryDataAsync(Library library)
        {
            try
            {
                Console.WriteLine("Загрузка данных...");
                
                // Пробуем загрузить из JSON (более новый формат)
                if (File.Exists("library_data.json"))
                {
                    library.LoadFromJson("library_data.json");
                    Console.WriteLine("Данные загружены из JSON файла");
                }
                // Если JSON нет, пробуем загрузить из текстового файла
                else if (File.Exists("library_data.txt"))
                {
                    library.LoadFromTextFile("library_data.txt");
                    Console.WriteLine("Данные загружены из текстового файла");
                }
                else
                {
                    Console.WriteLine("Файлы данных не найдены, будет создана новая библиотека");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при загрузке данных: {ex.Message}");
                Console.WriteLine("Будет создана новая библиотека");
            }
        }

        private static void InitializeSampleData(Library library)
        {
            // Добавляем тестовые данные только если библиотека пуста
            if (library.Books.Count == 0 && library.Readers.Count == 0)
            {
                Console.WriteLine("\nИнициализация тестовых данных...");
                
                try
                {
                    library.AddBook("978-5-699-12014-7", "Война и мир", "Лев Толстой", 1869, 5);
                    library.AddBook("978-5-17-090823-3", "Преступление и наказание", "Фёдор Достоевский", 1866, 3);
                    library.AddBook("978-5-04-110567-6", "Мастер и Маргарита", "Михаил Булгаков", 1967, 2);
                    
                    library.AddReader("Иванов Иван Иванович", "+7 (123) 456-78-90");
                    library.AddReader("Петров Петр Петрович", "+7 (987) 654-32-10");
                    library.AddReader("Сидорова Анна Михайловна", "+7 (555) 123-45-67");
                    
                    library.IssueBook("978-5-699-12014-7", 1, DateTime.Now.AddDays(14));
                    library.IssueBook("978-5-17-090823-3", 2, DateTime.Now.AddDays(7));
                    library.IssueBook("978-5-04-110567-6", 3, DateTime.Now.AddDays(21));
                    
                    Console.WriteLine("Тестовые данные успешно добавлены");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при добавлении тестовых данных: {ex.Message}");
                }
            }
        }

        private static async Task RunMainMenu(Library library)
        {
            while (true)
            {
                Console.WriteLine("\n=== Главное меню ===");
                Console.WriteLine("1. Просмотреть все книги");
                Console.WriteLine("2. Просмотреть всех читателей");
                Console.WriteLine("3. Просмотреть все выдачи");
                Console.WriteLine("4. Добавить новую книгу");
                Console.WriteLine("5. Зарегистрировать нового читателя");
                Console.WriteLine("6. Выдать книгу");
                Console.WriteLine("7. Вернуть книгу");
                Console.WriteLine("0. Выход");
                Console.Write("Выберите действие: ");

                var input = Console.ReadLine();
                
                try
                {
                    switch (input)
                    {
                        case "1":
                            Console.WriteLine("\n=== Список всех книг ===");
                            Console.WriteLine(library.GetAllBooksInfo());
                            break;
                            
                        case "2":
                            Console.WriteLine("\n=== Список всех читателей ===");
                            Console.WriteLine(library.GetAllReadersInfo());
                            break;
                            
                        case "3":
                            Console.WriteLine("\n=== Список всех выдач ===");
                            Console.WriteLine(library.GetAllIssuesInfo());
                            break;
                            
                        case "4":
                            await AddNewBook(library);
                            break;
                            
                        case "5":
                            await AddNewReader(library);
                            break;
                            
                        case "6":
                            await IssueBook(library);
                            break;
                            
                        case "7":
                            await ReturnBook(library);
                            break;
                            
                        case "0":
                            return;
                            
                        default:
                            Console.WriteLine("Неизвестная команда");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка: {ex.Message}");
                }
            }
        }

        private static async Task AddNewBook(Library library)
        {
            Console.WriteLine("\n=== Добавление новой книги ===");
            
            Console.Write("ISBN: ");
            var isbn = Console.ReadLine();
            
            Console.Write("Название: ");
            var title = Console.ReadLine();
            
            Console.Write("Автор: ");
            var author = Console.ReadLine();
            
            Console.Write("Год издания: ");
            var year = int.Parse(Console.ReadLine());
            
            Console.Write("Количество экземпляров: ");
            var copies = int.Parse(Console.ReadLine());
            
            library.AddBook(isbn, title, author, year, copies);
            Console.WriteLine("Книга успешно добавлена!");
            
            // Автосохранение после изменения данных
            await SaveLibraryDataAsync(library);
        }

        private static async Task AddNewReader(Library library)
        {
            Console.WriteLine("\n=== Регистрация нового читателя ===");
            
            Console.Write("ФИО: ");
            var fullName = Console.ReadLine();
            
            Console.Write("Телефон: ");
            var phone = Console.ReadLine();
            
            library.AddReader(fullName, phone);
            Console.WriteLine("Читатель успешно зарегистрирован!");
            
            // Автосохранение после изменения данных
            await SaveLibraryDataAsync(library);
        }

        private static async Task IssueBook(Library library)
        {
            Console.WriteLine("\n=== Выдача книги ===");
            
            Console.Write("ISBN книги: ");
            var isbn = Console.ReadLine();
            
            Console.Write("ID читателя: ");
            var readerId = int.Parse(Console.ReadLine());
            
            Console.Write("Срок возврата (в днях): ");
            var days = int.Parse(Console.ReadLine());
            
            library.IssueBook(isbn, readerId, DateTime.Now.AddDays(days));
            Console.WriteLine("Книга успешно выдана!");
            
            // Автосохранение после изменения данных
            await SaveLibraryDataAsync(library);
        }

        private static async Task ReturnBook(Library library)
        {
            Console.WriteLine("\n=== Возврат книги ===");
            
            Console.Write("ID выдачи: ");
            var issueId = int.Parse(Console.ReadLine());
            
            library.ReturnBook(issueId);
            Console.WriteLine("Книга успешно возвращена!");
            
            // Автосохранение после изменения данных
            await SaveLibraryDataAsync(library);
        }

        private static async Task SaveLibraryDataAsync(Library library)
        {
            try
            {
                // Сохраняем в оба формата
                library.SaveToTextFile("library_data.txt");
                library.SaveToJson("library_data.json");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при сохранении данных: {ex.Message}");
            }
        }
    }
}
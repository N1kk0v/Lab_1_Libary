using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MyWinFormsApp
{
    public class Library
    {
        private List<Book> books = new List<Book>();
        private List<Reader> readers = new List<Reader>();
        private List<BookIssue> issues = new List<BookIssue>();
        private int nextBookId = 1;
        private int nextReaderId = 1;
        private int nextIssueId = 1;

        [JsonPropertyName("books")]
        public IReadOnlyList<Book> Books => books.AsReadOnly();

        [JsonPropertyName("readers")]
        public IReadOnlyList<Reader> Readers => readers.AsReadOnly();

        [JsonPropertyName("issues")]
        public IReadOnlyList<BookIssue> Issues => issues.AsReadOnly();

        public void AddBook(string isbn, string title, string author, int year, int copies)
        {
            var book = new Book(isbn, title, author, year, copies);
            books.Add(book);
        }

        public void AddReader(string fullName, string phone)
        {
            var reader = new Reader(nextReaderId++, fullName, phone);
            readers.Add(reader);
        }

        public void IssueBook(string isbn, int readerId, DateTime dueDate)
        {
            var book = books.Find(b => b.ISBN == isbn) ?? 
                throw new ArgumentException("Книга не найдена");
            
            var reader = readers.Find(r => r.ID == readerId) ?? 
                throw new ArgumentException("Читатель не найден");
            
            var issue = new BookIssue(nextIssueId++, book, reader, DateTime.Now, dueDate);
            issues.Add(issue);
            book.Take();
        }

        public void ReturnBook(int issueId)
        {
            var issue = issues.Find(i => i.ID == issueId) ?? 
                throw new ArgumentException("Выдача не найдена");
            
            issue.ReturnBook();
            issue.Book.Return();
        }

        public string GetAllBooksInfo()
        {
            return string.Join("\n------------------\n", books.Select(b => b.GetInfo()));
        }

        public string GetAllReadersInfo()
        {
            return string.Join("\n------------------\n", readers.Select(r => r.GetInfo()));
        }

        public string GetAllIssuesInfo()
        {
            return string.Join("\n------------------\n", issues.Select(i => i.GetInfo()));
        }

        public void SaveToTextFile(string filePath)
        {
            try
            {
                using var sw = new StreamWriter(filePath, false, Encoding.UTF8);
                
                sw.WriteLine("=== Книги ===");
                foreach (var book in books)
                {
                    sw.WriteLine($"{book.ISBN}|{book.Title}|{book.Author}|{book.Year}|{book.TotalCopies}|{book.AvailableCopies}");
                }

                sw.WriteLine("=== Читатели ===");
                foreach (var reader in readers)
                {
                    sw.WriteLine($"{reader.ID}|{reader.FullName}|{reader.Phone}");
                }

                sw.WriteLine("=== Выдачи ===");
                foreach (var issue in issues)
                {
                    sw.WriteLine($"{issue.ID}|{issue.Book.ISBN}|{issue.Reader.ID}|" +
                               $"{issue.IssueDate:o}|{issue.DueDate:o}|{(issue.ReturnDate.HasValue ? issue.ReturnDate.Value.ToString("o") : "null")}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при сохранении в файл: {ex.Message}");
                throw;
            }
        }

        public void LoadFromTextFile(string filePath)
        {
            if (!File.Exists(filePath)) return;

            try
            {
                using var sr = new StreamReader(filePath, Encoding.UTF8);
                string? currentSection = null;
                string? line;

                while ((line = sr.ReadLine()) != null)
                {
                    if (line.StartsWith("==="))
                    {
                        currentSection = line;
                        continue;
                    }

                    switch (currentSection)
                    {
                        case "=== Книги ===":
                            var bookData = line.Split('|');
                            if (bookData.Length == 6)
                            {
                                books.Add(new Book(
                                    bookData[0], 
                                    bookData[1], 
                                    bookData[2], 
                                    int.Parse(bookData[3]), 
                                    int.Parse(bookData[4]))
                                {
                                    AvailableCopies = int.Parse(bookData[5])
                                });
                            }
                            break;

                        case "=== Читатели ===":
                            var readerData = line.Split('|');
                            if (readerData.Length == 3)
                            {
                                readers.Add(new Reader(
                                    int.Parse(readerData[0]), 
                                    readerData[1], 
                                    readerData[2]));
                                nextReaderId = Math.Max(nextReaderId, int.Parse(readerData[0]) + 1);
                            }
                            break;

                        case "=== Выдачи ===":
                            var issueData = line.Split('|');
                            if (issueData.Length == 6)
                            {
                                var book = books.Find(b => b.ISBN == issueData[1]);
                                var reader = readers.Find(r => r.ID == int.Parse(issueData[2]));
                                
                                if (book != null && reader != null)
                                {
                                    var issue = new BookIssue(
                                        int.Parse(issueData[0]), 
                                        book, 
                                        reader, 
                                        DateTime.Parse(issueData[3]), 
                                        DateTime.Parse(issueData[4]));
                                    
                                    if (issueData[5] != "null")
                                    {
                                        issue.ReturnBook();
                                    }
                                    
                                    issues.Add(issue);
                                    nextIssueId = Math.Max(nextIssueId, int.Parse(issueData[0]) + 1);
                                }
                            }
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при загрузке из файла: {ex.Message}");
                throw;
            }
        }

        public void SaveToJson(string filePath)
        {
            try
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true,
                    Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
                    ReferenceHandler = ReferenceHandler.Preserve,
                    DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
                };

                var data = new LibraryData
                {
                    Books = books,
                    Readers = readers,
                    Issues = issues.Select(i => new IssueData
                    {
                        ID = i.ID,
                        BookISBN = i.Book.ISBN,
                        ReaderID = i.Reader.ID,
                        IssueDate = i.IssueDate,
                        DueDate = i.DueDate,
                        ReturnDate = i.ReturnDate
                    }).ToList(),
                    NextIds = new NextIds
                    {
                        NextBookId = nextBookId,
                        NextReaderId = nextReaderId,
                        NextIssueId = nextIssueId
                    }
                };

                string jsonString = JsonSerializer.Serialize(data, options);
                File.WriteAllText(filePath, jsonString, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при сохранении в JSON: {ex.Message}");
                throw;
            }
        }

        public void LoadFromJson(string filePath)
        {
            if (!File.Exists(filePath)) return;

            try
            {
                string jsonString = File.ReadAllText(filePath, Encoding.UTF8);
                var options = new JsonSerializerOptions
                {
                    ReferenceHandler = ReferenceHandler.Preserve
                };

                var data = JsonSerializer.Deserialize<LibraryData>(jsonString, options);

                if (data != null)
                {
                    books = data.Books ?? new List<Book>();
                    readers = data.Readers ?? new List<Reader>();
                    issues = new List<BookIssue>();

                    foreach (var issueData in data.Issues ?? new List<IssueData>())
                    {
                        var book = books.Find(b => b.ISBN == issueData.BookISBN);
                        var reader = readers.Find(r => r.ID == issueData.ReaderID);

                        if (book != null && reader != null)
                        {
                            var issue = new BookIssue(
                                issueData.ID, 
                                book, 
                                reader, 
                                issueData.IssueDate, 
                                issueData.DueDate);

                            if (issueData.ReturnDate.HasValue)
                            {
                                issue.ReturnBook();
                            }

                            issues.Add(issue);
                        }
                    }

                    nextBookId = data.NextIds?.NextBookId ?? books.Count + 1;
                    nextReaderId = data.NextIds?.NextReaderId ?? readers.Max(r => r.ID) + 1;
                    nextIssueId = data.NextIds?.NextIssueId ?? (issues.Any() ? issues.Max(i => i.ID) + 1 : 1);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при загрузке из JSON: {ex.Message}");
                throw;
            }
        }

        private class LibraryData
        {
            public List<Book> Books { get; set; } = new List<Book>();
            public List<Reader> Readers { get; set; } = new List<Reader>();
            public List<IssueData> Issues { get; set; } = new List<IssueData>();
            public NextIds NextIds { get; set; } = new NextIds();
        }

        private class IssueData
        {
            public int ID { get; set; }
            public string BookISBN { get; set; } = string.Empty;
            public int ReaderID { get; set; }
            public DateTime IssueDate { get; set; }
            public DateTime DueDate { get; set; }
            public DateTime? ReturnDate { get; set; }
        }

        private class NextIds
        {
            public int NextBookId { get; set; } = 1;
            public int NextReaderId { get; set; } = 1;
            public int NextIssueId { get; set; } = 1;
        }
    }
}

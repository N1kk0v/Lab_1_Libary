// using System;

// namespace LibrarySystem
// {
//     public class BookIssue
//     {
//         public int ID { get; }
//         public Book Book { get; }
//         public Reader Reader { get; }
//         public DateTime IssueDate { get; }
//         public DateTime DueDate { get; }
//         public DateTime? ReturnDate { get; private set; }

//         public BookIssue(int id, Book book, Reader reader, DateTime issueDate, DateTime dueDate)
//         {
//             if (book == null)
//                 throw new ArgumentNullException(nameof(book));
//             if (reader == null)
//                 throw new ArgumentNullException(nameof(reader));
//             if (dueDate <= issueDate)
//                 throw new ArgumentException("Срок возврата должен быть позже даты выдачи");

//             ID = id;
//             Book = book;
//             Reader = reader;
//             IssueDate = issueDate;
//             DueDate = dueDate;
//             ReturnDate = null;
            
//             Book.Take();
//         }

//         public void ReturnBook()
//         {
//             if (ReturnDate.HasValue)
//                 throw new InvalidOperationException("Книга уже возвращена");
            
//             ReturnDate = DateTime.Now;
//             Book.Return();
//         }

//         public string GetInfo()
//         {
//             string status = ReturnDate.HasValue ? 
//                 $"Возвращена: {ReturnDate.Value.ToShortDateString()}" : 
//                 $"Ожидается возврат до: {DueDate.ToShortDateString()}";
            
//             return $"Выдача #{ID}\n{Book.GetInfo()}\n{Reader.GetInfo()}\n" +
//                    $"Дата выдачи: {IssueDate.ToShortDateString()}\n{status}";
//         }
//     }
// }
// using System;
// using System.Text.Json.Serialization;

// namespace LibrarySystem
// {
//     public class Book
//     {
//         // Свойства с JSON атрибутами
//         [JsonPropertyName("isbn")]
//         public string ISBN { get; set; }

//         [JsonPropertyName("title")]
//         public string Title { get; set; }

//         [JsonPropertyName("author")]
//         public string Author { get; set; }

//         [JsonPropertyName("year")]
//         public int Year { get; set; }

//         [JsonPropertyName("availableCopies")]
//         public int AvailableCopies { get; set; }

//         [JsonPropertyName("totalCopies")]
//         public int TotalCopies { get; set; }

//         // Конструктор для десериализации JSON
//         [JsonConstructor]
//         public Book(string isbn, string title, string author, int year, int availableCopies, int totalCopies)
//         {
//             ValidateInput(isbn, title, availableCopies, totalCopies);
            
//             ISBN = isbn;
//             Title = title;
//             Author = author;
//             Year = year;
//             AvailableCopies = availableCopies;
//             TotalCopies = totalCopies;
//         }

//         // Основной конструктор для ручного создания
//         public Book(string isbn, string title, string author, int year, int copies)
//             : this(isbn, title, author, year, copies, copies)
//         {
//         }

//         private void ValidateInput(string isbn, string title, int availableCopies, int totalCopies)
//         {
//             if (string.IsNullOrWhiteSpace(isbn))
//                 throw new ArgumentException("ISBN не может быть пустым");
//             if (string.IsNullOrWhiteSpace(title))
//                 throw new ArgumentException("Название не может быть пустым");
//             if (availableCopies < 0 || totalCopies < 0)
//                 throw new ArgumentException("Количество копий не может быть отрицательным");
//             if (availableCopies > totalCopies)
//                 throw new ArgumentException("Доступных копий не может быть больше общего количества");
//         }

//         public void Take()
//         {
//             if (AvailableCopies <= 0)
//                 throw new InvalidOperationException("Нет доступных копий этой книги");
//             AvailableCopies--;
//         }

//         public void Return()
//         {
//             if (AvailableCopies >= TotalCopies)
//                 throw new InvalidOperationException("Все копии этой книги уже возвращены");
//             AvailableCopies++;
//         }

//         public string GetInfo()
//         {
//             return $"Книга: {Title}\nАвтор: {Author}\nГод: {Year}\nISBN: {ISBN}\n" +
//                    $"Доступно: {AvailableCopies} из {TotalCopies}";
//         }

//         // Метод для клонирования книги (может быть полезен)
//         public Book Clone()
//         {
//             return new Book(ISBN, Title, Author, Year, AvailableCopies, TotalCopies);
//         }
//     }
// }
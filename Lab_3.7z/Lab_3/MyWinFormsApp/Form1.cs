using System;
using System.Drawing;
using System.Windows.Forms;
using MyWinFormsApp;
using System.IO;

namespace MyWinFormsApp
{
    public partial class Form1 : Form
    {
        private Library library;
        private string dataFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", "library_data.json");

        private Button btnAddReader;
        private TextBox txtReaderName;
        private TextBox txtReaderPhone;
        private ListBox lstReaders;
        private Button btnShowReaders;

        private Button btnAddBook;
        private TextBox txtBookISBN;
        private TextBox txtBookTitle;
        private TextBox txtBookAuthor;
        private TextBox txtBookYear;
        private TextBox txtBookCopies;
        private Button btnShowBooks;
        private ListBox lstBooks;

        private Button btnIssueBook;
        private TextBox txtIssueISBN;
        private TextBox txtIssueReaderId;
        private DateTimePicker dtpDueDate;
        private Button btnShowIssues;
        private ListBox lstIssues;

        private Button btnReturnBook;
        private TextBox txtReturnIssueId;

        private Button btnSaveData;

        public Form1()
        {
            InitializeComponent();
            library = new Library();

            InitializeControls();

            // Load data from JSON file
            try
            {
                library.LoadFromJson(dataFilePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void InitializeControls()
        {
            // Настройка формы
            this.Text = "Library System";
            this.Size = new Size(900, 650);

            int margin = 10;
            int labelWidth = 100;
            int controlHeight = 25;
            int startX = margin;
            int startY = margin;

            // Добавление читателя
            Label lblReaderName = new Label() { Text = "ФИО читателя:", Location = new Point(startX, startY), Width = labelWidth, Height = controlHeight };
            txtReaderName = new TextBox() { Location = new Point(startX + labelWidth, startY), Width = 150, Height = controlHeight };
            startY += controlHeight + margin;

            Label lblReaderPhone = new Label() { Text = "Телефон:", Location = new Point(startX, startY), Width = labelWidth, Height = controlHeight };
            txtReaderPhone = new TextBox() { Location = new Point(startX + labelWidth, startY), Width = 150, Height = controlHeight };
            startY += controlHeight + margin;

            btnAddReader = new Button() { Text = "Добавить читателя", Location = new Point(startX, startY), Width = 150, Height = controlHeight };
            btnAddReader.Click += new EventHandler(BtnAddReader_Click);
            startY += controlHeight + margin;

            btnShowReaders = new Button() { Text = "Показать всех читателей", Location = new Point(startX, startY), Width = 200, Height = controlHeight };
            btnShowReaders.Click += new EventHandler(BtnShowReaders_Click);
            startY += controlHeight + margin;

            lstReaders = new ListBox() { Location = new Point(startX, startY), Width = 300, Height = 150 };
            startY += 150 + margin;

            // Добавление книги
            int bookStartX = 350;
            int bookStartY = margin;

            Label lblBookISBN = new Label() { Text = "ISBN:", Location = new Point(bookStartX, bookStartY), Width = labelWidth, Height = controlHeight };
            txtBookISBN = new TextBox() { Location = new Point(bookStartX + labelWidth, bookStartY), Width = 150, Height = controlHeight };
            bookStartY += controlHeight + margin;

            Label lblBookTitle = new Label() { Text = "Название:", Location = new Point(bookStartX, bookStartY), Width = labelWidth, Height = controlHeight };
            txtBookTitle = new TextBox() { Location = new Point(bookStartX + labelWidth, bookStartY), Width = 150, Height = controlHeight };
            bookStartY += controlHeight + margin;

            Label lblBookAuthor = new Label() { Text = "Автор:", Location = new Point(bookStartX, bookStartY), Width = labelWidth, Height = controlHeight };
            txtBookAuthor = new TextBox() { Location = new Point(bookStartX + labelWidth, bookStartY), Width = 150, Height = controlHeight };
            bookStartY += controlHeight + margin;

            Label lblBookYear = new Label() { Text = "Год издания:", Location = new Point(bookStartX, bookStartY), Width = labelWidth, Height = controlHeight };
            txtBookYear = new TextBox() { Location = new Point(bookStartX + labelWidth, bookStartY), Width = 150, Height = controlHeight };
            bookStartY += controlHeight + margin;

            Label lblBookCopies = new Label() { Text = "Количество:", Location = new Point(bookStartX, bookStartY), Width = labelWidth, Height = controlHeight };
            txtBookCopies = new TextBox() { Location = new Point(bookStartX + labelWidth, bookStartY), Width = 150, Height = controlHeight };
            bookStartY += controlHeight + margin;

            btnAddBook = new Button() { Text = "Добавить книгу", Location = new Point(bookStartX, bookStartY), Width = 150, Height = controlHeight };
            btnAddBook.Click += new EventHandler(BtnAddBook_Click);
            bookStartY += controlHeight + margin;

            btnShowBooks = new Button() { Text = "Показать все книги", Location = new Point(bookStartX, bookStartY), Width = 200, Height = controlHeight };
            btnShowBooks.Click += new EventHandler(BtnShowBooks_Click);
            bookStartY += controlHeight + margin;

            lstBooks = new ListBox() { Location = new Point(bookStartX, bookStartY), Width = 300, Height = 150 };
            bookStartY += 150 + margin;

            // Выдача книги
            int issueStartX = 700;
            int issueStartY = margin;

            Label lblIssueISBN = new Label() { Text = "ISBN книги:", Location = new Point(issueStartX, issueStartY), Width = labelWidth, Height = controlHeight };
            txtIssueISBN = new TextBox() { Location = new Point(issueStartX + labelWidth, issueStartY), Width = 150, Height = controlHeight };
            issueStartY += controlHeight + margin;

            Label lblIssueReaderId = new Label() { Text = "ID читателя:", Location = new Point(issueStartX, issueStartY), Width = labelWidth, Height = controlHeight };
            txtIssueReaderId = new TextBox() { Location = new Point(issueStartX + labelWidth, issueStartY), Width = 150, Height = controlHeight };
            issueStartY += controlHeight + margin;

            Label lblDueDate = new Label() { Text = "Дата возврата:", Location = new Point(issueStartX, issueStartY), Width = labelWidth, Height = controlHeight };
            dtpDueDate = new DateTimePicker() { Location = new Point(issueStartX + labelWidth, issueStartY), Width = 150, Height = controlHeight };
            issueStartY += controlHeight + margin;

            btnIssueBook = new Button() { Text = "Выдать книгу", Location = new Point(issueStartX, issueStartY), Width = 150, Height = controlHeight };
            btnIssueBook.Click += new EventHandler(BtnIssueBook_Click);
            issueStartY += controlHeight + margin;

            btnShowIssues = new Button() { Text = "Показать все выдачи", Location = new Point(issueStartX, issueStartY), Width = 200, Height = controlHeight };
            btnShowIssues.Click += new EventHandler(BtnShowIssues_Click);
            issueStartY += controlHeight + margin;

            lstIssues = new ListBox() { Location = new Point(issueStartX, issueStartY), Width = 300, Height = 150 };
            issueStartY += 150 + margin;

            // Возврат книги
            int returnStartX = 700;
            int returnStartY = issueStartY;

            Label lblReturnIssueId = new Label() { Text = "ID выдачи:", Location = new Point(returnStartX, returnStartY), Width = labelWidth, Height = controlHeight };
            txtReturnIssueId = new TextBox() { Location = new Point(returnStartX + labelWidth, returnStartY), Width = 150, Height = controlHeight };
            returnStartY += controlHeight + margin;

            btnReturnBook = new Button() { Text = "Вернуть книгу", Location = new Point(returnStartX, returnStartY), Width = 150, Height = controlHeight };
            btnReturnBook.Click += new EventHandler(BtnReturnBook_Click);

            // Кнопка сохранения данных
            btnSaveData = new Button() { Text = "Сохранить данные", Location = new Point(10, 570), Width = 150, Height = controlHeight };
            btnSaveData.Click += BtnSaveData_Click;
            this.Controls.Add(btnSaveData);

            // Добавление контролов на форму
            this.Controls.Add(lblReaderName);
            this.Controls.Add(txtReaderName);
            this.Controls.Add(lblReaderPhone);
            this.Controls.Add(txtReaderPhone);
            this.Controls.Add(btnAddReader);
            this.Controls.Add(btnShowReaders);
            this.Controls.Add(lstReaders);

            this.Controls.Add(lblBookISBN);
            this.Controls.Add(txtBookISBN);
            this.Controls.Add(lblBookTitle);
            this.Controls.Add(txtBookTitle);
            this.Controls.Add(lblBookAuthor);
            this.Controls.Add(txtBookAuthor);
            this.Controls.Add(lblBookYear);
            this.Controls.Add(txtBookYear);
            this.Controls.Add(lblBookCopies);
            this.Controls.Add(txtBookCopies);
            this.Controls.Add(btnAddBook);
            this.Controls.Add(btnShowBooks);
            this.Controls.Add(lstBooks);

            this.Controls.Add(lblIssueISBN);
            this.Controls.Add(txtIssueISBN);
            this.Controls.Add(lblIssueReaderId);
            this.Controls.Add(txtIssueReaderId);
            this.Controls.Add(lblDueDate);
            this.Controls.Add(dtpDueDate);
            this.Controls.Add(btnIssueBook);
            this.Controls.Add(btnShowIssues);
            this.Controls.Add(lstIssues);

            this.Controls.Add(lblReturnIssueId);
            this.Controls.Add(txtReturnIssueId);
            this.Controls.Add(btnReturnBook);
        }

        private void BtnSaveData_Click(object sender, EventArgs e)
        {
            try
            {
                library.SaveToJson(dataFilePath);
                MessageBox.Show("Данные успешно сохранены");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}");
            }
        }

        private void BtnAddReader_Click(object sender, EventArgs e)
        {
            try
            {
                string fullName = txtReaderName.Text.Trim();
                string phone = txtReaderPhone.Text.Trim();

                library.AddReader(fullName, phone);

                MessageBox.Show("Читатель добавлен");
                txtReaderName.Clear();
                txtReaderPhone.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении читателя: {ex.Message}");
            }
        }

        private void BtnShowReaders_Click(object sender, EventArgs e)
        {
            lstReaders.Items.Clear();
            foreach (var reader in library.Readers)
            {
                lstReaders.Items.Add(reader.GetInfo());
            }
        }

        private void BtnAddBook_Click(object sender, EventArgs e)
        {
            try
            {
                string isbn = txtBookISBN.Text.Trim();
                string title = txtBookTitle.Text.Trim();
                string author = txtBookAuthor.Text.Trim();
                if (!int.TryParse(txtBookYear.Text.Trim(), out int year))
                {
                    MessageBox.Show("Неверный формат года");
                    return;
                }
                if (!int.TryParse(txtBookCopies.Text.Trim(), out int copies))
                {
                    MessageBox.Show("Неверный формат количества");
                    return;
                }

                library.AddBook(isbn, title, author, year, copies);

                MessageBox.Show("Книга добавлена");
                txtBookISBN.Clear();
                txtBookTitle.Clear();
                txtBookAuthor.Clear();
                txtBookYear.Clear();
                txtBookCopies.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении книги: {ex.Message}");
            }
        }

        private void BtnShowBooks_Click(object sender, EventArgs e)
        {
            lstBooks.Items.Clear();
            foreach (var book in library.Books)
            {
                lstBooks.Items.Add(book.GetInfo());
            }
        }

        private void BtnIssueBook_Click(object sender, EventArgs e)
        {
            try
            {
                string isbn = txtIssueISBN.Text.Trim();
                if (!int.TryParse(txtIssueReaderId.Text.Trim(), out int readerId))
                {
                    MessageBox.Show("Неверный формат ID читателя");
                    return;
                }
                DateTime dueDate = dtpDueDate.Value;

                library.IssueBook(isbn, readerId, dueDate);

                MessageBox.Show("Книга выдана");
                txtIssueISBN.Clear();
                txtIssueReaderId.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при выдаче книги: {ex.Message}");
            }
        }

        private void BtnShowIssues_Click(object sender, EventArgs e)
        {
            lstIssues.Items.Clear();
            foreach (var issue in library.Issues)
            {
                lstIssues.Items.Add(issue.GetInfo());
            }
        }

        private void BtnReturnBook_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(txtReturnIssueId.Text.Trim(), out int issueId))
                {
                    MessageBox.Show("Неверный формат ID выдачи");
                    return;
                }

                library.ReturnBook(issueId);

                MessageBox.Show("Книга возвращена");
                txtReturnIssueId.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при возврате книги: {ex.Message}");
            }
        }
    }
}
